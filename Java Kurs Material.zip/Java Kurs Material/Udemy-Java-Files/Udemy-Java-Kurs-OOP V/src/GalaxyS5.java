
public class GalaxyS5 extends Samsung implements ITelefon{

	// Eigenschaften / Attribute
	private String farbe;

	// Konstruktoren

	// Methoden
	@Override
	public void powerOn() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean esKlingelt() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean anrufen() {
		// TODO Auto-generated method stub
		return false;
	}

}
