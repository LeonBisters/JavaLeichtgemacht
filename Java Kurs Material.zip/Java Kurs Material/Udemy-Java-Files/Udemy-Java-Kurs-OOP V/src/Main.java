
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		GalaxyJ3 peterGalaxy = new GalaxyJ3(500, "Smartphone");
		peterGalaxy.powerOn();

	}

}
