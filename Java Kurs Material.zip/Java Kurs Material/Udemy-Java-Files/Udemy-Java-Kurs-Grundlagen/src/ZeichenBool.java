
public class ZeichenBool {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 8 primitive Datentypen in Java
		/*
		 * byte
		 * short
		 * int 
		 * long 
		 * float
		 * double
		 * boolean  (Ausgesprochen: bool)
		 * char     (Ausgesprochen: charakter = Zeichen)
		 */
		
		// Komplexe Datetypen
		// String (Zeichenkette)
		
		// <Datentyp> <Variablenamen> = <Wert> ;
		char varZeichen = '\u00A9';
		System.out.println("Das Bild unterliegt dem " + varZeichen);
		
		// true = wahr false = nicht wahr 
		boolean userKlick = false;
		
	
		
	}

}
