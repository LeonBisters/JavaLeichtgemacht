
public class intFloatDouble {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 8 primitive Datentypen in Java
				/*
				 * byte
				 * short
				 * int 
				 * long 
				 * float
				 * double
				 * boolean  (Ausgesprochen: bool)
				 * char     (Ausgesprochen: charakter = Zeichen)
				 */
				
				// Komplexe Datetypen
				// String (Zeichenkette)
				
				// <Datentyp> <Variablenamen> = <Wert> ;
				
				int varZahl1 = 10 / 3;      
				float varZahl2 = 10f / 3f;
				double varZahl3 = 10d / 3d;
				
				
				System.out.println("int " + varZahl1 );
				System.out.println("float " + varZahl2 );
				System.out.println("double " + varZahl3 );
				
		
	}

}
