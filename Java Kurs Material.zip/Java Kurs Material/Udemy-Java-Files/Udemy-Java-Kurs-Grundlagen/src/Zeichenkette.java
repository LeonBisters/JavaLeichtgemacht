
public class Zeichenkette {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 8 primitive Datentypen in Java
				/*
				 * byte
				 * short
				 * int 
				 * long 
				 * float
				 * double
				 * boolean  (Ausgesprochen: bool)
				 * char     (Ausgesprochen: charakter = Zeichen)
				 */
				// <Datentyp> <Variablenamen> = <Wert> ;
		char varZeichen = '!';
		
		String zeichenkette = new String();
		String varZeichenkette = "Ich bin eine Zeichenkette";
		
		String name = "Christian";
		String alter  = "25";
		
		System.out.println("Dein Name ist " + name + " dein Alter ist " + alter );
	}

}
