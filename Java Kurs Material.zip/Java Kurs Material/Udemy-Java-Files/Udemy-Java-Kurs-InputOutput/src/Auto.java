
public class Auto {
	
	int reifen;
	double preis;

}
