
public class Wrapper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Primitiver Datentyp = Primitive Variable = nur eine Information
		int zahl1 = 4;
		double zahl3 = 4.5;

		// Wrapper = Hülle
		// Wrapperklasse legen um die eine Information eine Hülle / Objekt
		Integer zahl2 = new Integer(4);
		Double zahl4 = new Double(zahl3);

	}

}
