import javax.swing.JFrame;

public class WasIstEinFramework {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * Was ist ein Framework?
		 * Klassen die schon fertig sind, man muss diese nur "auswendig lernen" 
		 */

		JFrame fenster1 = new JFrame("Mein erstes Fenster");
		// Breite = 400 Pixel Höhe auf 300 Pixel
		fenster1.setSize(400, 300);
		fenster1.setVisible(true);

	}

}
