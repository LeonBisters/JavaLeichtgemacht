
public class Reifen {

	// Eigenschaften / Attribute
	String reifenMarke;
	String reifenTyp;
	
	// Konstruktor
	public Reifen(){
		
	}
	
	public Reifen(String reifenMarke, String reifenTyp){
		this.reifenMarke = reifenMarke;
		this.reifenTyp = reifenTyp;
	}
	
	// Methoden
}
