
public class Mercedes {

}
