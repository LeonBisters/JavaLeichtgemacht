
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Hund bello = new Hund("bello", 3, 5, 42);
//		bello.essen();
//		
//		Kuh olga = new Kuh("Olga", 150, 600, 4);
//		olga.essen();
//		
//		BMW x1 = new BMW(130, 4, "Kompakt-SUV", true);
//	
//		Audi a3 = new Audi(180, 4, "Kompaktklasse", false);
//		a3.starten();
		
		Macbook macBook = new Macbook("Apple", 8, "Intel i5", 1200, true);
		macBook.starten();
		
	}

}
