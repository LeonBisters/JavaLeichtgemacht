package DSUebung;

public class Vergleiche {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name = "Christian";
		String name2 = new String("Christian");
		String name1 = "Peter";
		
		if(name.equals(name2)){
			System.out.println("Name passt");
		}else {
			System.out.println("Namen passen nicht");
		}


		
	}

}
